import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ListCell;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.util.Duration;

public class Tick extends ListCell<Packet> {
    double WIDTH = 60;
    Timeline anim;
    public Tick() {
        anim = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(prefWidthProperty(), 0d)),
                new KeyFrame(Duration.seconds(2), new KeyValue(prefWidthProperty(), WIDTH))
        );
    }
    @Override
    protected void updateItem(Packet item, boolean empty) {
        super.updateItem(item, empty);
        setText(null);
        setBackground(null);
        setPadding(new Insets(0));
        if(item == null || empty) setGraphic(null);
        else{
            var name = new Text(item.name);
            var volume = new Text(String.valueOf(item.volume));
            var price = new Text("@" + item.price);

            if(getListView().getItems().size() > 1){
                var index = getIndex() + 1;
                if(index != getListView().getItems().size()){
                    var previous = getListView().getItems().get(index);
                    Color color = null;

                    if(item.price > previous.price) color = Color.GREEN;
                    else  if(item.price < previous.price)color = Color.RED;
                    else color = Color.BLUE;

                    name.setFill(color);
                    volume.setFill(color);
                    price.setFill(color);
                }
            }
            var box = new VBox(name, volume, price);
            if(getIndex() == 0) box.setBackground(new Background(new BackgroundFill(Color.LIGHTBLUE, null,null)));
            else box.setBackground(new Background(new BackgroundFill(Color.LIGHTGRAY, null,null)));
            box.setAlignment(Pos.CENTER);
            box.setMinWidth(0);
            box.setMaxWidth(WIDTH);
            box.setPrefWidth(WIDTH);
            setGraphic(box);

            if(getIndex() == 0) {
                if(anim.getStatus() == Animation.Status.RUNNING) anim.stop();
                anim.play();
            }
        }
    }
}
