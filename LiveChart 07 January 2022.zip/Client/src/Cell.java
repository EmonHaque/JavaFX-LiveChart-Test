import javafx.geometry.Insets;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class Cell extends ListCell<Packet> {
    final double radius = 5;
    final double MAX_WIDTH = 30;

    @Override
    protected void updateItem(Packet item, boolean empty) {
        super.updateItem(item, empty);
        setBackground(null);
        setText(null);
        setPadding(new Insets(0));
        if (item == null || empty) setGraphic(null);
        else{
            setMaxHeight(MAX_WIDTH);
            double availableHeight = Chart.chartHeight - Chart.bottomLabelHeight;

            var text = new Text(item.time);
            text.setRotate(-90);
            text.setTranslateY(Chart.chartHeight - 12);

            var volumeHeight = availableHeight / Constants.MAX_VOLUME * item.volume;
            var volume = new Rectangle();
            volume.setWidth(MAX_WIDTH - 5);
            volume.setFill(Color.CORNFLOWERBLUE);
            volume.setOpacity(0.5);
            volume.setHeight(volumeHeight);
            volume.setTranslateY(availableHeight - volumeHeight);

            var priceHeight = availableHeight / Constants.MAX_PRICE * item.price;
            var circle = new Circle();
            circle.setFill(Color.CORAL);
            circle.setOpacity(0.5);
            circle.setRadius(radius);
            double circleY = availableHeight - priceHeight + radius;
            double circleX = MAX_WIDTH / 2 - radius / 2;
            circle.setTranslateY(circleY);
            circle.setTranslateX(circleX);

            var line = new Line();
            if (getListView().getItems().size() > 1) {
                if (getIndex() + 1 != getListView().getItems().size()) {
                    var previous = getListView().getItems().get(getIndex() + 1);
                    var previousPriceHeight = availableHeight / Constants.MAX_PRICE * previous.price;
                    line.setTranslateY(circleY);
                    line.setTranslateX(circleX);
                    line.setEndX(MAX_WIDTH);
                    line.setEndY(priceHeight - previousPriceHeight);
                    line.setStroke(Color.GRAY);
                }
            }

            var pane = new Pane(text, volume, circle, line);
            pane.setMaxWidth(MAX_WIDTH);
            pane.setMinWidth(MAX_WIDTH);
            pane.setPrefWidth(MAX_WIDTH);
            setGraphic(pane);
        }
    }
}
