import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Orientation;
import javafx.geometry.VPos;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Chart<T> extends Region {
    public static double bottomLabelHeight = 32;
    public static double chartHeight;
    ListView<T> volumeList;
    Text volTick1, volTick2, volTick3, priceTick1, priceTick2, priceTick3, volLabel, priceLabel;
    Line bottomLine, middleLine, topLine;
    double volTickWidth, priceTickWidth, volLabelWidth, priceLabelWidth;
    boolean isScrollBarDisabled;

    public Chart(ObservableList<T> list) {
        setMouseTransparent(true);
        volumeList = new ListView<>();
        volumeList.setBackground(null);
        volumeList.setOrientation(Orientation.HORIZONTAL);
        volumeList.setItems(list);
        volumeList.setCellFactory(v -> (ListCell<T>) new Cell());

        volTick1 = new Text("0");
        volTick2 = new Text(String.valueOf(Constants.MAX_VOLUME / 2));
        volTick3 = new Text(String.valueOf(Constants.MAX_VOLUME));
        volTick1.setUserData("volTick");
        volTick2.setUserData("volTick");
        volTick3.setUserData("volTick");
        priceTick1 = new Text("0");
        priceTick2 = new Text(String.valueOf(Constants.MAX_PRICE / 2));
        priceTick3 = new Text(String.valueOf(Constants.MAX_PRICE));
        priceTick1.setUserData("priceTick");
        priceTick2.setUserData("priceTick");
        priceTick3.setUserData("priceTick");

        volLabel = new Text("Volume");
        priceLabel = new Text("Price");
        volLabel.setUserData("volLabel");
        priceLabel.setUserData("priceLabel");
        volLabel.setRotate(-90);
        priceLabel.setRotate(90);
        volLabel.setFont(Font.font(null, FontWeight.BOLD, -1));
        priceLabel.setFont(Font.font(null, FontWeight.BOLD, -1));

        bottomLine = new Line();
        middleLine = new Line();
        topLine = new Line();
        bottomLine.setStroke(Color.GREEN);
        middleLine.setStroke(Color.GREEN);
        topLine.setStroke(Color.GREEN);

        getChildren().addAll(volLabel, volTick1, volTick2, volTick3, priceLabel, priceTick1, priceTick2, priceTick3, topLine, middleLine, bottomLine, volumeList);

        volTickWidth = volTick3.prefWidth(-1)  + 5;
        priceTickWidth = priceTick3.prefHeight(-1) + 5;
        volLabelWidth = volLabel.prefHeight(-1);
        priceLabelWidth = priceLabel.prefHeight(-1);
    }
    void disableScrollBar(){
        var hScroll = (ScrollBar) volumeList.queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        if (hScroll != null) {
            hScroll.setPrefHeight(0);
            hScroll.setMaxHeight(0);
            hScroll.setOpacity(1);
            hScroll.setVisible(false);
            //hScroll.setMouseTransparent(true);
        }
        var vScroll = (ScrollBar) volumeList.queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        if (vScroll != null) {
            vScroll.setPrefWidth(0);
            vScroll.setMaxWidth(0);
            vScroll.setOpacity(1);
            vScroll.setVisible(false);
            //vScroll.setMouseTransparent(true);
        }
    }

    @Override
    protected void layoutChildren() {
        var height = getHeight();
        if(chartHeight == height) return;

        if(!isScrollBarDisabled){
            disableScrollBar();
            isScrollBarDisabled = true;
        }

        var children = getChildren();
        var width = getWidth();

        var listWidth = width - volTickWidth - priceTickWidth - priceLabelWidth - volLabelWidth;
        double volTickY = height - bottomLabelHeight;
        double priceTickY = volTickY;
        double lineY = volTickY;
        double tickStep = volTickY / 2;
        for (var child : children){
            if(child instanceof Text label){
                if(label.getUserData().equals("volTick")){
                    label.setTranslateY(volTickY + 3);
                    label.setTranslateX(volLabelWidth);
                    volTickY -= tickStep;
                }
                else if(label.getUserData().equals("priceTick")){
                    label.setTranslateY(priceTickY + 3);
                    label.setTranslateX(width - label.prefWidth(-1) - priceLabelWidth);
                    priceTickY -= tickStep;
                }
                else if(label.getUserData().equals("priceLabel")){
                    label.setTranslateX(width - priceLabelWidth);
                    label.setTranslateY(height / 2 - priceLabelWidth / 2);
                }
                else if(label.getUserData().equals("volLabel")){
                    label.setTranslateY(height / 2 - volLabelWidth / 2);
                    label.setTranslateX(-volLabelWidth);
                }
            }
            else if(child instanceof Line line){
                line.setTranslateY(lineY);
                line.setStartX(volTickWidth + volLabelWidth);
                line.setEndX(width - priceTickWidth - priceLabelWidth);
                lineY -= tickStep;
            }
        }
        chartHeight = height;
        layoutInArea(volumeList, volTickWidth + volLabelWidth, 0, listWidth, chartHeight, getBaselineOffset(), HPos.LEFT, VPos.TOP);
    }
}
