import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class App extends Application {
    Sender sender;
    Receiver receiver;
    Processor processor;
    ObservableList<Packet> data;
    Chart<Packet> chartView;
    Ticker ticker;
    Button connect, disconnect, send, mock;
    TextField name, price, volume;
    Timer timer;
    TimerTask task;

    @Override
    public void init() throws Exception {
        super.init();
        sender = new Sender();
        receiver = new Receiver();
        data = FXCollections.observableArrayList();
        processor = new Processor(receiver.packets, data);

        connect = new Button("Connect");
        disconnect = new Button("Disconnect");
        name = new TextField();
        price = new TextField();
        volume = new TextField();
        send = new Button("Send");
        mock = new Button("Start mocking");
        name.setPromptText("Name");
        price.setPromptText("Price");
        volume.setPromptText("Volume");

        ticker = new Ticker(data);
        chartView = new Chart<>(data);

        connect.setOnMouseClicked(this::connect);
        send.setOnMouseClicked(this::send);
        mock.setOnMouseClicked(this::startMock);

        timer = new Timer();
        task = new TimerTask() {
            Random rand = new Random();
            @Override
            public void run() {
                var volume = rand.nextInt(Constants.MIN_VOLUME, Constants.MAX_VOLUME + 1);
                var price = rand.nextInt(Constants.MIN_PRICE, Constants.MAX_PRICE + 1);
                var packet = new Packet("00:00", "Item", price, volume);
                System.out.println("Price: " + price + " Volume: " + volume);
                sender.send(packet);
            }
        };
    }

    @Override
    public void start(Stage stage) throws Exception {
        var topBox = new HBox(connect, disconnect);
        topBox.setSpacing(10);
        topBox.setAlignment(Pos.CENTER);

        var middleBox = new HBox(name, price, volume, send, mock);
        middleBox.setSpacing(10);
        middleBox.setAlignment(Pos.CENTER);

        var content = new VBox(topBox, middleBox, ticker, chartView);
        VBox.setMargin(chartView, new Insets(5));
        VBox.setVgrow(chartView, Priority.ALWAYS);
        content.setSpacing(10);

        stage.setScene(new Scene(content, 640,480));
        stage.setTitle("Client");
        stage.show();
    }
    private void connect(MouseEvent e){
        sender.connect();
        receiver.connect();
        processor.start();
    }
    private void disconnect(MouseEvent e){
        sender.disconnect();
        receiver.disconnect();
    }
    private void send(MouseEvent e){
        var packet = new Packet("00:00", name.getText(), Integer.parseInt(price.getText()), Integer.parseInt(volume.getText()));
        if(sender == null) System.out.println("Sender is null");
        sender.send(packet);
    }
    private void startMock(MouseEvent e){
        timer.scheduleAtFixedRate(task, 0, 2000);
        mock.setText("Stop Mocking");
        mock.setOnMouseClicked(this::stopMock);
    }
    private void stopMock(MouseEvent e){
        timer.cancel();
        timer.purge();
        mock.setText("Start Mocking");
        mock.setOnMouseClicked(this::startMock);
    }
    public static void main(String[] args) {
        launch(args);
    }
}
