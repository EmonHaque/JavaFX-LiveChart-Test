import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;
import javafx.scene.layout.Region;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

public class Chart<T> extends Region {
    public static final double bottomLabelHeight = 32;
    public static double chartHeight;
    ListView<T> volumeList;
    Text leftLabel1, leftLabel2, leftLabel3, rightLabel1, rightLabel2, rightLabel3;
    Line bottomLine, middleLine, topLine;
    double leftLabelWidth, rightLabelWidth;
    public Chart(ObservableList<T> list) {
        volumeList = new ListView<>();
        volumeList.setBackground(null);
        volumeList.setOrientation(Orientation.HORIZONTAL);
        volumeList.setPadding(new Insets(0));
        volumeList.setItems(list);
        //volumeList.setCellFactory(v -> (ListCell<T>) new Cell());
        volumeList.setCellFactory(v -> (ListCell<T>) new CellCanvas());

        leftLabel1 = new Text("0");
        leftLabel2 = new Text(String.valueOf(Constants.MAX_VOLUME / 2));
        leftLabel3 = new Text(String.valueOf(Constants.MAX_VOLUME));
        leftLabel1.setUserData("leftLabel");
        leftLabel2.setUserData("leftLabel");
        leftLabel3.setUserData("leftLabel");
        rightLabel1 = new Text("0");
        rightLabel2 = new Text(String.valueOf(Constants.MAX_PRICE / 2));
        rightLabel3 = new Text(String.valueOf(Constants.MAX_PRICE));
        rightLabel1.setUserData("rightLabel");
        rightLabel2.setUserData("rightLabel");
        rightLabel3.setUserData("rightLabel");

        bottomLine = new Line();
        middleLine = new Line();
        topLine = new Line();
        bottomLine.setStroke(Color.GREEN);
        middleLine.setStroke(Color.GREEN);
        topLine.setStroke(Color.GREEN);

        getChildren().addAll(leftLabel1, leftLabel2, leftLabel3, rightLabel1, rightLabel2, rightLabel3, topLine, middleLine, bottomLine, volumeList);

        leftLabelWidth = leftLabel3.prefWidth(-1)  + 5;
        rightLabelWidth = rightLabel3.prefHeight(-1) + 5;
    }
    void disableScrollBar(){
        var hScroll = (ScrollBar) volumeList.queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        if (hScroll != null) {
            hScroll.setPrefHeight(0);
            hScroll.setMaxHeight(0);
            hScroll.setOpacity(1);
            hScroll.setVisible(false);
            hScroll.setMouseTransparent(true);
        }
//        var vScroll = (ScrollBar) volumeList.queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
//        if (vScroll != null) {
//            vScroll.setPrefWidth(0);
//            vScroll.setMaxWidth(0);
//            vScroll.setOpacity(1);
//            vScroll.setVisible(false);
//            vScroll.setMouseTransparent(true);
//        }
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        disableScrollBar();
        var children = getChildren();
        var width = getWidth();
        var listWidth = width - leftLabelWidth - rightLabelWidth;
        double leftLabelY = getHeight() - bottomLabelHeight;
        double rightLabelY = leftLabelY;
        double lineY = leftLabelY;
        double labelYStep = leftLabelY / 2;
        for (var child : children){
            if(child instanceof Text label){
                if(label.getUserData().equals("leftLabel")){
                    label.setTranslateY(leftLabelY);
                    leftLabelY -= labelYStep;
                }
                else{
                    label.setTranslateY(rightLabelY);
                    label.setTranslateX(width - label.prefWidth(-1));
                    rightLabelY -= labelYStep;
                }
            }
            else if(child instanceof Line line){
                line.setTranslateY(lineY);
                line.setStartX(leftLabelWidth);
                line.setEndX(width - rightLabelWidth);
                lineY -= labelYStep;
            }
        }
        chartHeight = getHeight();
        volumeList.setTranslateX(leftLabelWidth);
        volumeList.setMinSize(listWidth, chartHeight);
        volumeList.setMaxSize(listWidth, chartHeight);
        volumeList.setPrefSize(listWidth, chartHeight);
    }
}
