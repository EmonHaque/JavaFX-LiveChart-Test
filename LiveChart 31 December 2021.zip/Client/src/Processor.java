import javafx.application.Platform;
import javafx.collections.ObservableList;

import java.nio.ByteBuffer;
import java.util.concurrent.ArrayBlockingQueue;

public class Processor extends Thread{
    ArrayBlockingQueue<ByteBuffer> packets;
    ObservableList<Packet> collection;

    public Processor(ArrayBlockingQueue<ByteBuffer> packets, ObservableList<Packet> collection){
        this.packets = packets;
        this.collection = collection;
    }

    @Override
    public void run() {
        super.run();
        while (!isInterrupted()){
            try {
                var buffer = packets.take();
                var packet = Packet.getPacket(buffer);
                Platform.runLater(() -> collection.add(0, packet));
            } catch (InterruptedException e) {
                System.out.println("Client processing thread interrupted");
                break;
                //e.printStackTrace();
            }
        }
    }
}
