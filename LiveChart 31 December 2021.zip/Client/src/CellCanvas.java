import javafx.scene.canvas.Canvas;
import javafx.scene.control.ListCell;

public class CellCanvas extends ListCell<Packet> {
    final double MAX_WIDTH = 30;
    final double availableHeight = Chart.chartHeight - Chart.bottomLabelHeight;

    @Override
    protected void updateItem(Packet item, boolean empty) {
        super.updateItem(item, empty);
        setBackground(null);
        setText(null);
        if(item == null || empty) setGraphic(null);
        else{
            var canvas = new Canvas(MAX_WIDTH, availableHeight);
            var dc = canvas.getGraphicsContext2D();
            dc.fillText(item.time, 0, Chart.chartHeight - 10);
            setGraphic(canvas);
        }
    }
}
