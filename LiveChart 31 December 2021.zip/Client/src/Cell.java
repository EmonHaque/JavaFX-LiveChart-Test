import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class Cell extends ListCell<Packet> {
    final double radius = 5;
    final double MAX_WIDTH = 30;
    final double availableHeight = Chart.chartHeight - Chart.bottomLabelHeight;
    @Override
    protected void updateItem(Packet item, boolean empty) {
        super.updateItem(item, empty);
        setBackground(null);
        setText(null);
        if(item == null || empty) setGraphic(null);
        else{
            setMaxHeight(MAX_WIDTH);
            var text = new Text(item.time);
            text.setRotate(-90);

            var volumeHeight = availableHeight / Constants.MAX_VOLUME * item.volume;
            var volume = new Rectangle();
            volume.setWidth(MAX_WIDTH - 5);
            volume.setFill(Color.CORNFLOWERBLUE);
            volume.setOpacity(0.5);
            volume.setHeight(volumeHeight);

            var priceHeight = availableHeight / Constants.MAX_PRICE * item.price;
            var circleY = getHeight() / 2 - Chart.bottomLabelHeight - priceHeight;

            var circle = new Circle();
            circle.setFill(Color.CORAL);
            circle.setOpacity(0.5);
            circle.setRadius(radius);
            circle.setTranslateY(circleY + radius / 2);

            var pane = new Pane();
            if(getListView().getItems().size() > 1){
                if(getIndex() + 1 != getListView().getItems().size() -1) {
                    var previous = getListView().getItems().get(getIndex() + 1);
                    var previousPriceHeight = availableHeight / Constants.MAX_PRICE * previous.price;
                    var previousCircleY = getHeight() / 2 - Chart.bottomLabelHeight - previousPriceHeight;

                    var line = new Line();
                    line.setEndX(MAX_WIDTH * 1.5);
                    line.setStartY(circleY);
                    line.setEndY(previousCircleY);

                    pane.getChildren().add(line);
                    pane.setTranslateX((MAX_WIDTH / 2.0));
                    pane.setTranslateY(Chart.chartHeight / 2);
                }
            }

            var box = new VBox();
            box.getChildren().addAll(volume, new Group(text));
            box.setAlignment(Pos.BOTTOM_CENTER);
            setAlignment(Pos.BOTTOM_CENTER);

            var stack = new StackPane(box, circle, pane);
            stack.setMaxWidth(MAX_WIDTH);
            stack.setMinWidth(MAX_WIDTH);
            stack.setPrefWidth(MAX_WIDTH);
            setGraphic(stack);
        }
    }
}
