import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.ListCell;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;

public class Cell extends ListCell<Packet> {
    final double MAX_WIDTH = 30;
    final double availableHeight = Chart.chartHeight - Chart.bottomLabelHeight;
    @Override
    protected void updateItem(Packet item, boolean empty) {
        super.updateItem(item, empty);
        setBackground(null);
        setText(null);
        if(item == null || empty) setGraphic(null);
        else{
            setMaxHeight(MAX_WIDTH);
            var text = new Text(item.time);
            text.setRotate(-90);

            var volumeHeight = availableHeight / Constants.MAX_VOLUME * item.volume;
            var volume = new Rectangle();
            volume.setWidth(MAX_WIDTH - 5);
            volume.setFill(Color.CORNFLOWERBLUE);
            volume.setHeight(volumeHeight);

            var priceHeight = availableHeight / Constants.MAX_PRICE * item.price;
            var circleY = getHeight() / 2 - Chart.bottomLabelHeight - priceHeight;

            var circle = new Circle();
            circle.setFill(Color.CORAL);
            circle.setRadius(5);
            circle.setTranslateY(circleY);

//            var line = new Line();
//            if(getListView().getItems().size() > 1){
//                var previous = getListView().getItems().get(getIndex() + 1);
//                var previousPriceHeight = availableHeight / Constants.MAX_PRICE * previous.price;
//                var previousCircleY = getHeight() / 2 - Chart.bottomLabelHeight - previousPriceHeight;
//                line.setStartY(circleY);
//                line.setEndY(previousCircleY);
//                line.setEndX(getWidth());
//            }

            var box = new VBox();
            box.getChildren().addAll(volume, new Group(text));
            box.setAlignment(Pos.BOTTOM_CENTER);
            setAlignment(Pos.BOTTOM_CENTER);

            var pane = new StackPane(box, circle);
            setGraphic(pane);
        }
    }
}
