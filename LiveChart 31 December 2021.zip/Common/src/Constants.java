public class Constants {
    public static final String HOST = "127.0.0.1";
    public static final int PORT_RECEIVE = 4444;
    public static final int PORT_SEND = 5555;
    public static final int PACKET_SIZE = 28;
    public static final int MIN_VOLUME = 50;
    public static final int MAX_VOLUME = 300;
    public static final int MIN_PRICE = 30;
    public static final int MAX_PRICE = 100;
}
