import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Packet {
    public String time, name;
    public int price, volume;

    public Packet() {}
    public Packet(String time, String name, int price, int volume) {
        this.time = time;
        this.name = name;
        this.price = price;
        this.volume = volume;
    }

    public ByteBuffer getBytes() throws UnsupportedEncodingException {
        // 5 for timestamp, 15 for name TextField in Client, 4 for volume and 4 for price TextFields
        var array = ByteBuffer.allocateDirect(5 + 15 + 4 + 4);
        array.put(time.getBytes(),0,5);
        var nameBytes = name.getBytes();
        var nameArray = new byte[15];
        System.arraycopy(nameBytes, 0, nameArray, 0, nameBytes.length);

        array.put(nameArray);
        array.putInt(price);
        array.putInt(volume);
        array.flip();
        return array;
    }
    public static Packet getPacket(ByteBuffer b){
        b.flip();
        var packet = new Packet();
        var time = new byte[5];
        var name = new byte[15];
        b.get(time);
        b.get(name);
        packet.time = new String(time);
        packet.name = new String(name).trim();
        packet.price = b.getInt();
        packet.volume = b.getInt();
        return packet;
    }
    public static void stamp(ByteBuffer b){
        var time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
        b.put(time.getBytes());
        b.position(0);
    }
}
