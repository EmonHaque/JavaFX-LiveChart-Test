import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.ArrayBlockingQueue;

public class App extends Application {
    AsynchronousServerSocketChannel sendChannel, receiveChannel;
    ObservableList<AsynchronousSocketChannel> senders, receivers;
    ListView<AsynchronousSocketChannel> sendersView, receiversView;
    ArrayBlockingQueue<ByteBuffer> packets;
    Thread broadcaster;
    Button start, stop;

    @Override
    public void init() throws Exception {
        super.init();
        senders = FXCollections.observableArrayList();
        receivers = FXCollections.observableArrayList();
        packets = new ArrayBlockingQueue<>(1000);
        start = new Button("Start");
        stop = new Button("Stop");
        sendersView = new ListView<>(senders);
        receiversView = new ListView<>(receivers);
        start.setOnMouseClicked(this::listen);
    }

    @Override
    public void start(Stage stage) throws Exception {
        var topBox = new HBox(start, stop);
        var bottomBox = new HBox(sendersView, receiversView);
        topBox.setSpacing(10);
        bottomBox.setSpacing(10);
        topBox.setAlignment(Pos.CENTER);
        bottomBox.setAlignment(Pos.CENTER);

        sendersView.setCellFactory(v -> new ClientCell());
        receiversView.setCellFactory(v -> new ClientCell());

        var content = new VBox(topBox, bottomBox);
        content.setSpacing(10);
        VBox.setMargin(bottomBox, new Insets(0,0,10,0));
        VBox.setVgrow(bottomBox, Priority.ALWAYS);

        stage.setScene(new Scene(content, 640,480));
        stage.setTitle("Server");
        stage.show();
    }
    void listen(MouseEvent e){
        System.out.println("listening");
        try {
            receiveChannel = AsynchronousServerSocketChannel.open();
            receiveChannel.bind(new InetSocketAddress(Constants.HOST, Constants.PORT_SEND));
            sendChannel = AsynchronousServerSocketChannel.open();
            sendChannel.bind(new InetSocketAddress(Constants.HOST, Constants.PORT_RECEIVE));
            broadcaster = new Thread(this::broadcast);
            broadcaster.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        receiveChannel.accept(null, new CompletionHandler<>() {
            @Override
            public void completed(AsynchronousSocketChannel result, Object attachment) {
                receiveChannel.accept(null, this);
                read(result);
                Platform.runLater(() -> receivers.add(result));
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                System.out.println("no more connection!");
            }
        });
        sendChannel.accept(null, new CompletionHandler<>() {
            @Override
            public void completed(AsynchronousSocketChannel result, Object attachment) {
                sendChannel.accept(null, this);
                Platform.runLater(() -> senders.add(result));
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                System.out.println("no more connection!");
            }
        });
    }
    void read(AsynchronousSocketChannel channel){
        var buffer = ByteBuffer.allocate(Constants.PACKET_SIZE);
        channel.read(buffer, null, new CompletionHandler<Integer, Object>() {
            @Override
            public void completed(Integer result, Object attachment) {
                var packet = ByteBuffer.allocateDirect(Constants.PACKET_SIZE);
                packet.put(buffer.flip());
                packets.add(packet);
                //System.out.println("read " + result + " size " + packet.capacity() + " pos " + packet.position());
                buffer.clear();
                channel.read(buffer, null, this);
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                try {
                    channel.close();
                    System.out.println("failed to read");
                    //Platform.runLater(() -> clients.remove(channel));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    void broadcast(){
        while (!broadcaster.isInterrupted()){
            try {
                var packet = packets.take().flip();
                Packet.stamp(packet);
                for(var client : senders){
                    client.write(packet);
                }
            } catch (InterruptedException e) {
                break;
            }
        }
        System.out.println("broadcast closing ...");
    }
    void stopListening(MouseEvent e){

    }
    public static void main(String[] args) {
        launch(args);
    }
}
