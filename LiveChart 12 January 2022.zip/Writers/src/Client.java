import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.StandardSocketOptions;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class Client {
    Socket socket;
    Timer timer;
    TimerTask sendTask;
    OutputStream stream;
    int count;
    public Client() {
        socket = new Socket();
        try {
            //socket.setOption(StandardSocketOptions.TCP_NODELAY, true);
            //socket.setOption(StandardSocketOptions.SO_LINGER, 10000);
            socket.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_SEND), 0);
            stream = socket.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (stream != null) {
            timer = new Timer();
            sendTask = new TimerTask() {
                Random rand = new Random();
                @Override
                public void run() {
                    var volume = rand.nextInt(Constants.MIN_VOLUME, Constants.MAX_VOLUME + 1);
                    var price = rand.nextInt(Constants.MIN_PRICE, Constants.MAX_PRICE + 1);
                    var packet = new Packet("00:00", "Item", price, volume);
                    try {
                        stream.write(packet.getBytes().array());
                        count++;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            };
            timer.scheduleAtFixedRate(sendTask, 0, 2);
        }

    }

    public void stop() {
        sendTask.cancel();
        timer.cancel();
        timer.purge();
        try {
            stream.flush();
            stream.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getCount() {
        return count;
    }
}
