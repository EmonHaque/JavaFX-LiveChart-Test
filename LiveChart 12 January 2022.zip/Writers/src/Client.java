import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.SocketChannel;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.stream.IntStream;

public class Client {
    SocketChannel channel;
    Timer timer;
    TimerTask task;
    int count = 0;
    boolean isConnected = false;
    int[] ports = IntStream.rangeClosed(Constants.PORT_SEND, Constants.PORT_SEND + 100).toArray();
    public Client() {

        int index = 0;
        try {
            channel = SocketChannel.open();
            channel.setOption(StandardSocketOptions.SO_LINGER, 60000);
            channel.setOption(StandardSocketOptions.TCP_NODELAY, true);
            channel.setOption(StandardSocketOptions.SO_SNDBUF, Constants.PACKET_SIZE);

        } catch (IOException e) {
            e.printStackTrace();
        }

        while (!isConnected) {
            try {
                isConnected = channel.connect(new InetSocketAddress(Constants.HOST, ports[index]));
            } catch (IOException e) {
                index++;
                if(index > 100)  break;
            }
        }
        if(!isConnected) return;

        timer = new Timer();
        task = new TimerTask() {
            final Random rand = new Random();

            @Override
            public void run() {
                var volume = rand.nextInt(Constants.MIN_VOLUME, Constants.MAX_VOLUME + 1);
                var price = rand.nextInt(Constants.MIN_PRICE, Constants.MAX_PRICE + 1);
                var packet = new Packet("00:00", "Item", price, volume);
                try {
                    channel.write(packet.getBytes());
                    count++;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };
        timer.scheduleAtFixedRate(task, 0, 30000);
    }

    public void stop() {
        if(!isConnected) return;
        timer.cancel();
        timer.purge();
        try {
            channel.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public int getCount() {
        return count;
    }
}
