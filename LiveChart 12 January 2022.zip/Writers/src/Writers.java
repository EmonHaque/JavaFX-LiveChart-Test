import java.util.Scanner;

public class Writers {
    public static void main(String[] args) {
        int number = 300;
        Client[] array = new Client[number];
        long start = System.currentTimeMillis();
        for (int i = 0; i < number; i++) {
            array[i] = new Client();
        }

        new Scanner(System.in).nextLine();
        int count = 0;
        for (int i = 0; i < number; i++) {
            array[i].stop();
            count += array[i].getCount();
        }
        long end = System.currentTimeMillis();
        System.out.println(String.format("%,d", count) + " packets sent in " + String.format("%,d", end - start) + " ms");
    }
}
