import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ExecutionException;

public class Receiver {
    private AsynchronousSocketChannel channel;
    private boolean isConnected;
    private ByteBuffer buffer;
    public ArrayBlockingQueue<ByteBuffer> packets;

    public Receiver() {
        buffer = ByteBuffer.allocateDirect(Constants.PACKET_SIZE);
        packets = new ArrayBlockingQueue<>(5000000);
    }
    public boolean isConnected() {
        return isConnected;
    }
    public void connect(){
        try {
            channel = AsynchronousSocketChannel.open();
            channel.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_RECEIVE), null, new CompletionHandler<Void, Object>() {
                @Override
                public void completed(Void result, Object attachment) {
                    isConnected = true;
                    read();
                }
                @Override
                public void failed(Throwable exc, Object attachment) {
                    isConnected = false;
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void read(){
        channel.read(buffer, null, new CompletionHandler<Integer, Object>() {
            @Override
            public void completed(Integer result, Object attachment) {
                int read = result;
                while (read < Constants.PACKET_SIZE){
                    var future = channel.read(buffer);
                    try {
                        read += future.get();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                }
                var packet = ByteBuffer.allocateDirect(Constants.PACKET_SIZE);
                packet.put(buffer.flip());
                packets.add(packet);
                buffer.clear();
                channel.read(buffer, null, this);
            }
            @Override
            public void failed(Throwable exc, Object attachment) {
                try {
                    channel.close();
                    isConnected = false;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void disconnect(){
        if(channel != null){
            try {
                channel.close();
                isConnected = false;
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
