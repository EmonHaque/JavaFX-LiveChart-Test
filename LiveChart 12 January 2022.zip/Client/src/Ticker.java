import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.geometry.Orientation;
import javafx.scene.AccessibleAttribute;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollBar;

public class Ticker extends ListView<Packet> {
    boolean isScrollDisabled;
    public IntegerProperty data;
    public Ticker(ObservableList<Packet> packets) {
        setMouseTransparent(true);
        data = new SimpleIntegerProperty();
        setMaxHeight(150);
        setBackground(null);
        setCellFactory( v -> new Tick());
        setItems(packets);
        setOrientation(Orientation.HORIZONTAL);
        getItems().addListener(new ListChangeListener<Packet>() {
            @Override
            public void onChanged(Change<? extends Packet> c) {
                data.set(getItems().size());
            }
        });
    }
    void disableScrollBar(){
        var hScroll = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.HORIZONTAL_SCROLLBAR);
        if (hScroll != null) {
            hScroll.setPrefHeight(0);
            hScroll.setMaxHeight(0);
            hScroll.setOpacity(1);
            hScroll.setVisible(false);
            //hScroll.setMouseTransparent(true);
        }
        var vScroll = (ScrollBar) queryAccessibleAttribute(AccessibleAttribute.VERTICAL_SCROLLBAR);
        if (vScroll != null) {
            vScroll.setPrefWidth(0);
            vScroll.setMaxWidth(0);
            vScroll.setOpacity(1);
            vScroll.setVisible(false);
            //vScroll.setMouseTransparent(true);
        }
    }

    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if(!isScrollDisabled) disableScrollBar();
    }
}
