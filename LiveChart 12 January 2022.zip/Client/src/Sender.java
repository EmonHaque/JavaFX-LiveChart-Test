import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutionException;

public class Sender {
    private AsynchronousSocketChannel channel;
    private boolean isConnected;
    public Sender() {

    }
    public boolean isConnected() {
        return isConnected;
    }
    public void connect(){
        try {
            channel = AsynchronousSocketChannel.open();
            channel.connect(new InetSocketAddress(Constants.HOST, Constants.PORT_SEND), null, new CompletionHandler<Void, Object>() {
                @Override
                public void completed(Void result, Object attachment) {
                    isConnected = true;
                }
                @Override
                public void failed(Throwable exc, Object attachment) {
                    isConnected = false;
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void send(Packet p){
        try {
            var buffer = p.getBytes();
            var future = channel.write(buffer);
            future.get();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void disconnect(){
        if(channel != null){
            try {
                channel.close();
                isConnected = false;
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
