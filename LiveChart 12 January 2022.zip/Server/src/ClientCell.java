import javafx.scene.control.ListCell;

import java.io.IOException;
import java.nio.channels.AsynchronousSocketChannel;

public class ClientCell extends ListCell<AsynchronousSocketChannel> {
    @Override
    protected void updateItem(AsynchronousSocketChannel item, boolean empty) {
        super.updateItem(item, empty);
        if(item == null || empty){
            setText(null);
            setGraphic(null);
        }else{
            try {
                var address = item.getRemoteAddress();
                setText(address.toString());
                setGraphic(null);
            } catch (IOException e) {
                //e.printStackTrace();
            }
        }
    }
}
